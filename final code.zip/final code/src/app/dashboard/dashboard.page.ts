import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { MenuController, NavController, Platform } from '@ionic/angular';
import { AuthService } from 'src/app/services/auth.service';
import { User } from 'src/app/models/user';
import { Router } from '@angular/router';
import { PostService } from 'src/app/services/post.service';
import { DummytempService } from 'src/app/services/dummytemp.service';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { DatePicker } from '@ionic-native/date-picker/ngx';
import { LoaderService } from 'src/app/services/loader.service';
import { PopoverController } from '@ionic/angular';
// import { File } from '@ionic-native/file/ngx';
import { AlertService } from 'src/app/services/alert.service';
import { ProfilepopoverComponent } from '../profilepopover/profilepopover.component';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { Clipboard } from '@ionic-native/clipboard/ngx';
import 'capacitor-razorpay';
import { PaymentService } from 'src/app/services/payment.service';
import { Plugins } from '@capacitor/core';
const { Checkout } = Plugins;
import { AlertController } from '@ionic/angular';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
})
export class DashboardPage implements OnInit, OnDestroy {
  downloadURL: any;
  today: any;
  user: User;
  public authUser: any;
  postList: any;
  paymentStatus: number;
  public userID: any;
  public partyId: any;
  // dummyDataImage: any;
  // dummyDataVdo: any;
  selectedDate: any;
  // dummyVdoList = [];
  // dummImgList = [];
  dummyData: any;
  screenshotElement: any;
  userData: any;

  emailId: any;
  mobile: any;
  plans: any;
  userName: any;
  userPic: any;
  designationtitle: any;
  facebook: any;
  tweeter: any;
  party_id: any;
  footeroption: any;

  constructor(
    private menu: MenuController,
    // private file: File,
    private socialSharing: SocialSharing,
    private plt: Platform,
    private clipboard: Clipboard,
    private datepicker: DatePicker,
    private callNumber: CallNumber,
    private router: Router,
    private loaderService: LoaderService,
    private popoverCtrl: PopoverController,
    private authService: AuthService,
    private alertService: AlertService,
    private alertController: AlertController,
    private navCtrl: NavController,
    private postService: PostService,
    private paymentService: PaymentService,
    private dummytempService: DummytempService
  ) {}

  ngOnInit(): void {
    this.menu.enable(true);
    // this.dummyTemplate();
    this.today = new Date().toISOString();
    const todayDate = new Date();
    const today = todayDate;
    this.selectedDate =
      today.getFullYear() +
      '-' +
      (today.getMonth() + 1) +
      '-' +
      today.getDate();

    this.getPlansList();
    setTimeout(() => {
      this.userInfo();
    }, 3000);
    // setTimeout(() => {
    //   if (
    //     this.designationtitle === null ||
    //     this.facebook === null ||
    //     this.tweeter === null ||
    //     this.party_id === null ||
    //     this.footeroption === null
    //   ) {
    //     this.showAlert();
    //   }
    // }, 5000);
  }

  ngOnDestroy() {
    this.menu.enable(true);
    // this.getAllpost();
    // this.dummyTemplate();
    this.today = new Date().toISOString();
    const todayDate = new Date();
    const today = todayDate;
    this.selectedDate =
      today.getFullYear() +
      '-' +
      (today.getMonth() + 1) +
      '-' +
      today.getDate();

    this.userInfo();
  }

  async callSupport(n: string) {
    this.callNumber
      .callNumber(n, true)
      .then(() => console.log('Launched dialer!'))
      .catch(() => console.log('Error launching dialer'));
  }

  async showPopover(event) {
    const popover = await this.popoverCtrl.create({
      component: ProfilepopoverComponent,
      showBackdrop: true,
      mode: 'ios',
      cssClass: 'user-profile',
      event,
    });
    await popover.present();
  }

  userInfo() {
    this.authService.user().then(() => {
      if (this.authService.isAuthenticated) {
        this.authUser = this.authService.token;
        this.userProfileDetail(this.authUser.id);
      }
    });
  }

  userProfileDetail(uid) {
    this.authService.getUserProfile(uid).subscribe((res) => {
      this.userData = res.user_detail;
      this.paymentStatus = res.user_detail.payment_status;
      this.userPic = this.userData.user_image;
      this.emailId = this.userData.email;
      this.mobile = this.userData.mobile_no;
      this.userID = this.userData.id;
      this.party_id = this.userData.party_id;
      console.log(this.userData);
      this.getAllpost();
    });
  }
  // userInfo() {
  //   this.authService.user().then(() => {
  //     if (this.authService.isAuthenticated) {
  //       this.authUser = this.authService.token;
  //       this.userProfileDetail(this.authUser.id);
  //     }
  //   });
  // }

  // userProfileDetail(uid) {
  //   this.authService.getUserProfile(uid).subscribe((res) => {
  //     this.userData = res.user_detail;
  //     this.paymentStatus = res.user_detail;
  //     this.userName = this.userData.first_name + ' ' + this.userData.last_name;
  //     this.mobile = this.userData.mobile_no;
  //     this.emailId = this.userData.email;
  //     this.userPic = this.userData.user_image;
  //     this.designationtitle = this.userData.designationtitle;
  //     this.facebook = this.userData.facebook;
  //     this.tweeter = this.userData.tweeter;
  //     this.party_id = this.userData.party_id;
  //     this.footeroption = this.userData.footeroption;

  //     this.userID = this.userData.id;

  //     console.log(
  //       res.user_detail
  //     );

  //     this.getAllpost();
  //   });
  // }

  async copyText(text) {
    this.clipboard.copy(text);
    this.alertService.presentToast('Text Copied');
  }

  doRefresh(event) {
    setTimeout(() => {
      this.getAllpost();
      event.target.complete();
    }, 1500);
  }

  getAllpost() {
    this.postData(this.userID, this.party_id, this.selectedDate);
    this.dummyTemplated(this.party_id);
  }

  postData(uid, pid, sdate) {
    console.log(uid + '|' + pid + '|' + sdate);
    this.postService.getPost(uid, pid, sdate).subscribe((res) => {
      console.log(res);
      this.postList = res.user_post;
    });
  }

  getDashboardItemsByDate() {
    let today: any = new Date();
    let selectedDate: any = new Date(this.selectedDate);
    this.selectedDate =
      selectedDate.getFullYear() +
      '-' +
      (selectedDate.getMonth() + 1) +
      '-' +
      selectedDate.getDate();

    this.postData(this.userID, this.party_id, this.selectedDate);
    console.log(this.selectedDate);
  }

  async shareTwitter(cap, imageurl) {
    this.loaderService.presentLoading();
    const img = 'https://electionadvisor.in/eadvisor/upload/' + imageurl;
    this.socialSharing
      .share(cap, null, img, null)
      .then(() => {})
      .catch((e) => {});
  }

  async shareFacebook(imageurl) {
    this.loaderService.presentLoading();
    const img = 'https://electionadvisor.in/eadvisor/upload/' + imageurl;
    this.socialSharing
      .shareViaFacebook(null, img, null)
      .then(() => {})
      .catch((e) => {});
  }

  async shareWhatsapp(cap, imageurl) {
    this.loaderService.presentLoading();
    const img = 'https://electionadvisor.in/eadvisor/upload/' + imageurl;
    this.socialSharing
      .share(cap, null, img, null)
      .then(() => {})
      .catch((e) => {});
  }

  async vdoshare(cap, imageurl) {
    this.loaderService.presentLoading();
    const img = 'https://electionadvisor.in/eadvisor/' + imageurl;
    this.socialSharing
      .share(cap, null, img, null)
      .then(() => {})
      .catch((e) => {});
  }

  dummyTemplated(pid) {
    this.dummytempService.getDpostByPid(pid).subscribe((res) => {
      console.log(res.user_post);
      this.dummyData = res.user_post;
    });
  }

  // dummyTemplate() {
  //   this.loaderService.presentLoading();
  //   this.postService.getDummyPost().subscribe((res) => {
  //     this.dummyDataImage = res.dummytemplate.image;
  //     this.dummyDataVdo = res.dummytemplate.video;
  //     this.dummyVdoList = [];
  //     for (let i = 0; i < this.dummyDataVdo.file.length; i++) {
  //       this.dummyVdoList.push(
  //       { url: this.dummyDataVdo.file[i], thumb: this.dummyDataVdo.thumb[i] }
  //       );
  //     }
  //   });
  // }

  checkPlan() {
    this.navCtrl.navigateRoot('/paymentplan');
  }

  getPlansList() {
    this.paymentService.getPlans().subscribe((data) => {
      this.plans = data.plan_list;
      console.log(data);
    });
  }

  async loadCheckout(fld_price) {
    const options = {
      key: 'rzp_live_rDbAntssbzc4G8',
      amount: fld_price * 100,
      description: 'Annual Subscription',
      image: 'https://www.electionadvisor.in//assets/images/logo.png',
      currency: 'INR',
      name: 'Election Adviser',
      prefill: {
        email: this.emailId,
        contact: this.mobile,
        name: this.userName,
      },
      theme: {
        color: '#F37254',
      },
    };
    try {
      let data = await Checkout.open(options);

      const paymentID = data.response.razorpay_payment_id;
      this.paymentService
        .getPayment(this.userID, paymentID)
        .subscribe((data) => {
          this.alertService.presentToast('Payment Success');
        });
    } catch (error) {
      this.alertService.presentToast(error.message);
    }
  }
}

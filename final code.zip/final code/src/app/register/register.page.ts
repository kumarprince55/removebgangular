import { Component, OnInit } from '@angular/core';
import { ModalController, NavController, ActionSheetController } from '@ionic/angular';
import { LeadersLibraryPage } from '../leaders-library/leaders-library.page';
import { NgForm } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { AlertService } from 'src/app/services/alert.service';
import { LoaderService } from 'src/app/services/loader.service';
import { StorageService } from '../services/storage.service';
import { Camera, CameraResultType, CameraSource, Photo } from '@capacitor/camera';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Storage } from '@capacitor/storage';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {
  mobile_no: number;
  smob: number;
  motp: number;
  checkMotp: number;
  registerCheck: boolean;
  stateList: any;
  cityList: any;
  partyList: any;
  profileUpload: any;
  imageType: any;
  public imagePath: SafeResourceUrl;
  footerList: any;
  radioVal: any;

  constructor(
    private actionSheetCtrl: ActionSheetController,
    public modalCtrl: ModalController,
    private authService: AuthService,
    private navCtrl: NavController,
    private alertService: AlertService,
    private loaderService: LoaderService,
    private storageService: StorageService,
    private sanitizer: DomSanitizer,
  ) {}

  ngOnInit() {
    this.getNumber();
    this.getStateList();
    this.getPartyList();
  }

  async dismiss() {
    return await this.modalCtrl.dismiss();
  }

  getNumber() {
    return this.storageService.get('registerStatus').then(
      (data) => {
        this.smob = data.mobile_no;
        this.checkMotp = data.mobile_otp;
        this.registerCheck = data.register;
      },
      (error) => {
        // this.mobile = null;
        // this.isLoggedIn=false;
      }
    );
  }

  selectChange(e) {
    console.log(e);
  }

  getPartyList() {
    this.authService.getParties().subscribe((res) => {
      this.partyList = res.party_list;
    });
  }

  onchangeParty(e){
    const pid = e.target.value;
    this.getFooters(pid);
  }

  onRadioChange(value) {
    // this.form.get('typeofsession').setValue(value, {
    //   onlyself: true,
    // });
    // this.form.get('typeofsession').setValue(value)
    this.radioVal = value;
    console.log(value);
  }

  // async register(form: NgForm) {
  //   const email = '';
  //   const password = '';
  //   const mobileNo = this.smob;
  //   const logged_in_token = this.smob + this.checkMotp;
  //   const partyIdcheck = form.value.partyid;
  //   const fusername = form.value.user_name;
  //   const photo = this.profileUpload;
  //   const photoextension = this.imageType;

  //   console.log(partyIdcheck.length);
   
  //   if (partyIdcheck.length > 0 && fusername.length > 0) {
  //     this.loaderService.presentLoading();
  //     this.authService
  //       .register(
  //         form.value.user_name,
  //         form.value.last_name,
  //         email,
  //         mobileNo,
  //         password,
  //         form.value.state,
  //         form.value.city,
  //         logged_in_token,
  //         form.value.partyid,
  //         form.value.designationtitle,
  //         photo,
  //         photoextension,
  //         form.value.facebook,
  //         form.value.tweeter,
  //         form.value.instagram,
  //         form.value.koo,
  //         form.value.whatsapp,
  //         form.value.footeroption = this.radioVal,
  //       )
  //       .subscribe(
  //         (data) => {
  //           this.alertService.presentToast('Registered Successfully');
  //           console.log(data);
  //           if (data['success'] == true) {
  //             this.loginR(this.smob, this.checkMotp);
  //           }
  //           this.dismiss();
  //           // this.otpverifyModel()
  //         },
  //         (error) => {
  //           console.log(error);
  //         }
  //       );
  //   }else{
  //     this.alertService.presentToast('Please Name and Party is mandatory.');
  //   }
  // }


  async register(form: NgForm) {
    const email = '';
    const password = '';
    const mobileNo = this.smob;
    const logged_in_token = this.smob + this.checkMotp;
    const partyIdcheck = form.value.partyid;
    const fusername = form.value.user_name;
    const photo = this.profileUpload;
    const photoextension = this.imageType;

    console.log(partyIdcheck.length);
   
    if (partyIdcheck.length > 0 && fusername.length > 0) {
      this.loaderService.presentLoading();
      this.authService
        .register(
          form.value.user_name,
          form.value.last_name,
          email,
          mobileNo,
          password,
          form.value.state,
          form.value.city,
          logged_in_token,
          form.value.partyid,
          form.value.designationtitle,
          photo,
          photoextension,
          form.value.facebook,
          form.value.tweeter,
          form.value.instagram,
          form.value.koo,
          form.value.whatsapp,
          form.value.footeroption = this.radioVal,
        )
        .subscribe(
          (data) => {
            this.alertService.presentToast('Registered Successfully');
            console.log(data);
            if (data['success'] == true) {
              this.loginR(this.smob, this.checkMotp);
            }
            this.dismiss();
            // this.otpverifyModel()
          },
          (error) => {
            console.log(error);
          }
        );
    }else{
      this.alertService.presentToast('Please Name and Party is mandatory.');
    }
  }

  async loginR(mobile, motp) {
    this.authService.login(mobile, motp).subscribe(
      (data) => {
        this.alertService.presentToast('Logged In');
        this.navCtrl.navigateRoot('dashboard');
        this.dismiss();
      },
      (error) => {
        console.log(error);
      }
    );
  }

  async keyPressAlphaNumeric(event) {
    var inp = String.fromCharCode(event.keyCode);
    if (/[0-9]/.test(inp)) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  getStateList() {
    this.authService.getState().subscribe((res) => {
      this.stateList = res.state_list;
    });
  }

  async onChangeState(e) {
    this.getCityList(e.target.value);
  }

  getCityList(id) {
    this.authService.getCity(id).subscribe((res) => {
      this.cityList = res.city_list;
    });
  }

  convertBlobToBase64 = (blob: Blob) => new Promise((resolve, reject) => {
    const reader = new FileReader;
    reader.onerror = reject;
    reader.onload = () => resolve(reader.result);
    reader.readAsDataURL(blob);
  });

  async chooseImage(source: CameraSource) {
    try {
      const image = await Camera.getPhoto({
        quality: 60,
        width: 400,
        height: 400,
        preserveAspectRatio: true,
        allowEditing: true,
        correctOrientation: true,
        source: source,
        resultType: CameraResultType.Uri,
      });

      this.imageType= image.format;
      const safeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(image.webPath);
      this.imagePath = safeUrl;
      const response = await fetch(image.webPath);
      const blob = await response.blob();

      const base64 = await this.convertBlobToBase64(blob) as string;
      this.profileUpload= base64;
      this.imageType= image.format;
    } catch (error) {
      console.warn(error);
    }
  }

  async presentActionSheet() {
    const actionSheet = await this.actionSheetCtrl.create({
      header: 'Choose an option',
      buttons: [{
        text: 'Photo Library',
        handler: () => {
          this.chooseImage(CameraSource.Photos);
        }
      }, {
        text: 'Camera',
        handler: () => {
          this.chooseImage(CameraSource.Camera);
        }
      }, {
        text: 'Cancel',
        role: 'cancel'
      }]
    });
    return await actionSheet.present();
  }
  

  getFooters(pid){
    this.authService.getPartiesFooter(pid).subscribe((res) => {
      this.footerList = res.party_list.options;
      console.log(this.footerList)
    });
  }

  async leadersLibraryMdl() {
    const modal = await this.modalCtrl.create({
      component: LeadersLibraryPage,
      animated: true,
      mode: 'ios',
      backdropDismiss: false,
      cssClass: 'library-modal',
    })
    return await modal.present();
  }
}

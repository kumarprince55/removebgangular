import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { NavigationExtras, Router, ActivatedRoute } from '@angular/router';
import { PopoverController } from "@ionic/angular";
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
@Component({
  selector: 'app-profilepopover',
  templateUrl: './profilepopover.component.html',
  styleUrls: ['./profilepopover.component.scss'],
})
export class ProfilepopoverComponent implements OnInit {
  constructor(  private authService: AuthService, private iab:InAppBrowser, private router: Router, private popoverController: PopoverController) { }

  ngOnInit() {}

  async userlogout() {
    this.authService.logout();
    this.dismissPopover();
  }

  async openAnyPage(url){
    this.iab.create(url);
  }

  async profileCheck (){
    this.dismissPopover()
    this.router.navigate(['/profile']);
  }

  dismissPopover() {
     this.popoverController.dismiss();
  }
}

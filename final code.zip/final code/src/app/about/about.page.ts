import { Component, OnInit } from '@angular/core';
import { PagelistService } from 'src/app/services/pagelist.service';
import { AuthService } from 'src/app/services/auth.service';
import { PopoverController } from '@ionic/angular';
import { ProfilepopoverComponent } from '../profilepopover/profilepopover.component';
@Component({
  selector: 'app-about',
  templateUrl: './about.page.html',
  styleUrls: ['./about.page.scss'],
})
export class AboutPage implements OnInit {
  pageList:any;
  public authUser: any;
  userData: any;
  paymentStatus: number;
  about:any;
  services:any;
  privacy:any;
  termscondition:any;
  userPic:any;
 
  constructor(
    private popoverCtrl: PopoverController,
    private pagelistService: PagelistService,
    private authService: AuthService,
  ) { }

  ngOnInit() {
    this.getPage();
    this.userInfo();
  }

  async showPopover(event) {
    const popover = await this.popoverCtrl.create({
      component: ProfilepopoverComponent,
      showBackdrop: true,
      mode: 'ios',
      cssClass: 'user-profile',
      event,
    });
    await popover.present();
  }

  userInfo() {
    this.authService.user().then(() => {
      if (this.authService.isAuthenticated) {
        this.authUser = this.authService.token;
        this.userProfileDetail(this.authUser.id);
      }
    });
  }

  userProfileDetail(uid) {
    this.authService.getUserProfile(uid).subscribe((res) => {
      this.userData = res.user_detail;
      this.paymentStatus = res.user_detail.payment_status;
      this.userPic = this.userData.user_image;
      console.log(this.userData)
    });
  }

  getPage(){
    this.pagelistService.getPages().subscribe((res)  =>  {
      console.log(res);
      this.pageList = res.page_list;

      this.about = this.pageList[0];
      this.privacy = res[1];
      this.termscondition = res[2];
      this.services = res[3]

      console.log(this.about);
     
    });
  }
}

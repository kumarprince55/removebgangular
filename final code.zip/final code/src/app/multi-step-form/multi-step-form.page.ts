import { Component, OnInit, ViewChild } from '@angular/core';
import { LeadersLibraryPage } from '../leaders-library/leaders-library.page';
import { ActionSheetController, IonContent, IonSlides, NavController, ModalController } from '@ionic/angular';
import { AbstractControl, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { Camera, CameraResultType, CameraSource, Photo } from '@capacitor/camera';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Storage } from '@capacitor/storage';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { StorageService } from '../services/storage.service';
// const { Camera } = Plugins;
import { AuthService } from 'src/app/services/auth.service';
import { LoaderService } from 'src/app/services/loader.service';
import { AlertService } from 'src/app/services/alert.service';
@Component({
  selector: 'app-multi-step-form',
  templateUrl: './multi-step-form.page.html',
  styleUrls: ['./multi-step-form.page.scss'],
})
export class MultiStepFormPage implements OnInit {

  @ViewChild(IonContent, { static: true }) ionContent: IonContent;
  @ViewChild(IonSlides, { static: false }) ionSlides: IonSlides;
  @ViewChild('billingFormRef', { static: false }) billingFormRef: NgForm;
  @ViewChild('shippingFormRef', { static: false }) shippingFormRef: NgForm;
  @ViewChild('paymentFormRef', { static: false }) paymentFormRef: NgForm;

  partyList: any;
  stateList: any;
  cityList: any;
  radioVal: any;
  footerList: any;
  mobile_no: number;
  smob: number;
  motp: number;
  checkMotp: number;
  registerCheck: boolean;
  logintoken: any;
  profileUpload: any;
  imageType: any;

  public billingForm: FormGroup;
  public paymentForm: FormGroup;
  public shippingForm: FormGroup;

  public imagePath: SafeResourceUrl;

  public times = [];

  public slidesOpts = {
    allowTouchMove: false,
    autoHeight: true,
  };

  constructor(
    private actionSheetCtrl: ActionSheetController,
    private navCtrl: NavController,
    private sanitizer: DomSanitizer,
    private authService: AuthService,
    private loaderService: LoaderService,
    private alertService: AlertService,
    public modalCtrl: ModalController,
    private storageService: StorageService
  ) {}

  ngOnInit() {
    this.getNumber();
    this.setupForm();
    this.buildSlides();
    this.getPartyList();
    this.getStateList();
  }

  dismissLogin() {
    this.modalCtrl.dismiss();
  }

  async leadersLibraryMdl() {
    const modal = await this.modalCtrl.create({
      component: LeadersLibraryPage,
      animated: true,
      mode: 'ios',
      backdropDismiss: false,
      cssClass: 'library-modal',
    })

    return await modal.present();
  }

  openLibrary(){
    this.leadersLibraryMdl();
  }

  public slides: string[];
  public currentSlide: string;
  public isBeginning: boolean = true;
  public isEnd: boolean = false;


  get billingFullName(): AbstractControl {
    return this.billingForm.get('first_name');
  }

  get billingDesignation(): AbstractControl {
    return this.billingForm.get('designationtitle');
  }

  get billingPartyid(): AbstractControl {
    return this.billingForm.get('partyid');
  }

  get billingPhoto(): AbstractControl {
    return this.billingForm.get('photo');
  }


  get billingEmail(): AbstractControl {
    return this.billingForm.get('email_id');
  }

  get billingCity(): AbstractControl {
    return this.billingForm.get('city');
  }

  get billingState(): AbstractControl {
    return this.billingForm.get('state');
  }

  get shippingPhone(): AbstractControl {
    return this.shippingForm.get('mobile_no');
  }


  // get paymentExpiration(): AbstractControl {
  //   return this.paymentForm.get('expiration');
  // }

  // get paymentCvv(): AbstractControl {
  //   return this.paymentForm.get('cvv');
  // }

  ionViewDidEnter() {
    this.ionSlides.updateAutoHeight();
  }

  buildSlides() {
    const slides = ['Personal Info', 'Social Handles', 'Party Leaders'];
    this.currentSlide = slides[0];
    this.slides = slides;
  }

  getNumber() {
    return this.storageService.get('registerStatus').then(
      (data) => {
        this.smob = data.mobile_no;
        this.checkMotp = data.mobile_otp;
        this.registerCheck = data.register;
        this.logintoken = this.smob + this.checkMotp;
        console.log(this.logintoken);
      },
      (error) => {
        // this.mobile = null;
        // this.isLoggedIn=false;
      }
    );
  }

  setupForm() {
    // this.billingForm.controls['photo'].setValue(this.profileUpload);
    // this.billingForm.controls['photoextension'].setValue(this.imageType);
    this.billingForm = new FormGroup({
      user_name: new FormControl('', Validators.required),
      last_name: new FormControl(''),
      photo: new FormControl('', Validators.required),
      photoextension: new FormControl('', Validators.required),
      designationtitle: new FormControl('', Validators.required),
      partyid: new FormControl('', Validators.required),
      email_id: new FormControl(''),
      password: new FormControl(''),
      logged_in_token: new FormControl(''),
      state: new FormControl('', Validators.required),
      city: new FormControl('', Validators.required),
    });

    this.shippingForm = new FormGroup({
      twitter: new FormControl(''),
      facebook: new FormControl(''),
      insta: new FormControl(''),
      koo: new FormControl(''),
      whatsapp: new FormControl(''),
      mobile_no: new FormControl(''),
    });

    this.paymentForm = new FormGroup({
      number: new FormControl('', Validators.required),
      expiration: new FormControl('', Validators.required),
      cvv: new FormControl('', Validators.required),
    });
  } 

  async onSlidesChanged() {
    const index = await this.ionSlides.getActiveIndex();
    this.currentSlide = this.slides[index];
    this.isBeginning = await this.ionSlides.isBeginning();
    this.isEnd = await this.ionSlides.isEnd();
  }

  onSlidesDidChange() {
    this.ionContent.scrollToTop();
  }

  onBackButtonTouched() {
    this.ionSlides.slidePrev();
    this.ionContent.scrollToTop();
  }

  onNextButtonTouched() {
    
    if (this.currentSlide === 'Personal Info') {

      this.billingFormRef.onSubmit(undefined);

      if (this.billingForm.valid) {
        this.ionSlides.slideNext();
        this.ionContent.scrollToTop();
      }

    } else if (this.currentSlide === 'Social Handles') {
      
      this.shippingFormRef.onSubmit(undefined);

      if (this.shippingForm.valid) {
        this.ionSlides.slideNext();
        this.ionContent.scrollToTop();
      }

    } else if (this.currentSlide === 'Party Leaders') {

      this.paymentFormRef.onSubmit(undefined);

      if (this.paymentForm.valid) {
        this.navCtrl.navigateRoot('/dashboard', {
          animated: true,
          animationDirection: 'forward',
        });
      }

    }  else {

      this.ionSlides.slideNext();
      this.ionContent.scrollToTop();
    }
  }

  convertBlobToBase64 = (blob: Blob) => new Promise((resolve, reject) => {
    const reader = new FileReader;
    reader.onerror = reject;
    reader.onload = () => resolve(reader.result);
    reader.readAsDataURL(blob);
  });

  async chooseImage(source: CameraSource) {

    try {
      const image = await Camera.getPhoto({
        quality: 60,
        width: 400,
        height: 400,
        preserveAspectRatio: true,
        allowEditing: true,
        correctOrientation: true,
        source: source,
        resultType: CameraResultType.Uri,
      });

      this.imageType= image.format;
      const safeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(image.webPath);
      this.imagePath = safeUrl;
      const response = await fetch(image.webPath);
      const blob = await response.blob();
      const base64 = await this.convertBlobToBase64(blob) as string;
      this.profileUpload= base64;
      this.imageType= image.format;

      // Send encoded string to server...

    } catch (error) {
      console.warn(error);
    }

  }

  async presentActionSheet() {

    const actionSheet = await this.actionSheetCtrl.create({
      header: 'Choose an option',
      buttons: [{
        text: 'Photo Library',
        handler: () => {
          this.chooseImage(CameraSource.Photos);
        }
      }, {
        text: 'Camera',
        handler: () => {
          this.chooseImage(CameraSource.Camera);
        }
      }, {
        text: 'Cancel',
        role: 'cancel'
      }]
    });

    return await actionSheet.present();
  }

  originalOrder = (): number => {
    return 0;
  }

  getStateList() {
    this.authService.getState().subscribe((res) => {
      this.stateList = res.state_list;
    });
  }

  async onChangeState(e) {
    this.getCityList(e.target.value);
  }

  getCityList(id) {
    this.authService.getCity(id).subscribe((res) => {
      this.cityList = res.city_list;
    });
  }

  getPartyList(){
    this.authService.getParties().subscribe((res) => {
      this.partyList = res.party_list;
    });
  }

  onchangeParty(e){
    const pid = e.target.value;
    this.getFooters(pid);
  }

  onRadioChange(value) {
    // this.form.get('typeofsession').setValue(value, {
    //   onlyself: true,
    // });
    // this.form.get('typeofsession').setValue(value)
    this.radioVal = value;
    console.log(value);
  }

  getFooters(pid){
    this.authService.getPartiesFooter(pid).subscribe((res) => {
      this.footerList = res.party_list.options;
      console.log(this.footerList)
    });
  }

  async register(form: NgForm) {
    const email = '';
    const password = '';
    const mobileNo = this.smob;
    const logged_in_token = this.smob + this.checkMotp;
    const partyIdcheck = form.value.partyid;
    const fusername = form.value.user_name

    console.log(partyIdcheck.length);
   
    if (partyIdcheck.length > 0 && fusername.length > 0) {
      this.loaderService.presentLoading();
      this.authService
        .register(
          form.value.user_name,
          form.value.last_name,
          email,
          mobileNo,
          password,
          form.value.state,
          form.value.city,
          logged_in_token,
          form.value.partyid,
          form.value.designationtitle
        )
        .subscribe(
          (data) => {
            this.alertService.presentToast('Registered Successfully');
            console.log(data);
            if (data['success'] == true) {
              this.loginR(this.smob, this.checkMotp);
            }

            this.dismiss();
            // this.otpverifyModel()
          },
          (error) => {
            console.log(error);
          }
        );
    }else{
      this.alertService.presentToast('Please Name and Party is mandatory.');
    }
  }


  async loginR(mobile, motp) {
    this.authService.login(mobile, motp).subscribe(
      (data) => {
        this.alertService.presentToast('Logged In');
        this.navCtrl.navigateRoot('dashboard');
        this.dismiss();
      },
      (error) => {
        console.log(error);
      }
    );
  }



  async dismiss() {
    return await this.modalCtrl.dismiss();
  }

}

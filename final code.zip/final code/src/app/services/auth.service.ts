import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { tap, map } from 'rxjs/operators';
import { Storage } from '@capacitor/storage';
import { BehaviorSubject, Observable } from 'rxjs';
//import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { EnvService } from './env.service';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { Platform, LoadingController, AlertController, ToastController } from '@ionic/angular';
import { StorageService } from './storage.service';
//import { AuthConstants } from '../config/auth-constants';


@Injectable({
  providedIn: 'root'
})

export class AuthService {
  userData$ = new BehaviorSubject<any>([]);
  isLoggedIn = false;
  token:any;
  mobile: any;

  authenticationState = new BehaviorSubject(false);

  constructor(
    private http: HttpClient,
    private storageService: StorageService,
    private env: EnvService,
    private plt: Platform,
    private router: Router,
    private toastController: ToastController
  ) { 
    this.plt.ready().then(() => {
      this.checkToken();
    });
  }

  async checkToken() {
    Storage.get({ key: 'token' }).then(res => {
      if (res.value !== null) {
        this.authenticationState.next(true);
        this.router.navigate(['dashboard']);
      }else {
        this.authenticationState.next(false);
        this.router.navigate(['home']);
      }
    })
  }

  loginOtp(mobile) {
    return this.http.get<any>(this.env.API_URL + 'check_user?'+this.env.API_ACCESS_TOKEN+''+'&mobile_no='+mobile)
      .pipe(
        tap(mobile => {
          this.storageService.store('registerStatus', mobile)
          .then(
            () => {
              console.log('Token Stored');
            },
            error => console.error('Error storing item', error)
          );
        }),
        map((data) => {
          return data;
        })
      );
  }

  login(mobile, otp): Observable<any> {
    return this.http.post(this.env.API_URL + 'login_user?'+this.env.API_ACCESS_TOKEN+''+'&mobile_no='+mobile+'&mobile_otp='+otp,{})
    .pipe(
      tap(token => {
        this.storageService.store('token', token)
        .then(
          () => {
            //console.log('Token Stored');
            this.authenticationState.next(true);
          },
          error => console.error('Error storing item', error)
        );
        this.token = token;
        this.isLoggedIn = true;
        return token;
      }),
    );
  }

  // register(fName, lName, email, mobile, password, state, city, logged_in_token, partyid, designationtitle, photo, photoextension, twitter, facebook, instagram, koo, whatsapp, footeroption) {
  //   return this.http.post(this.env.API_URL + 'user_registration?'+this.env.API_ACCESS_TOKEN+'&user_name='+fName+'&last_name='+lName+'&email_id='+email+'&mobile_no='+mobile+'&password='+password+'&state='+state+'&city='+city+'&logged_in_token='+logged_in_token+'&partyid='+partyid+'&designationtitle='+designationtitle+'&photo='+photo+'&photoextension='+photoextension+'&twitter='+twitter+'&facebook='+facebook+'&insta='+instagram+'&koo='+koo+'&whatsapp='+whatsapp+'&footertype='+footeroption,
  //     {}
  //   )
  // }

  register(fName, lName, email, mobile, password, state, city, logged_in_token, partyid, designationtitle, photo, photoextension, twitter, facebook, instagram, koo, whatsapp, footeroption) {
    
    let postData = {
      "name": "Customer004",
      "photo": photo,
    }

    return this.http.post(this.env.API_URL + 'testapi', postData,
    {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    }
    )
  }

  updateProfile(id, fName, lName, email, state, city, party, footeroption, designationtitle, leadersname, facebook, tweeter, instagram, koo){
    return this.http.post(this.env.API_URL + 'update_profile?'+this.env.API_ACCESS_TOKEN+'&id='+id+'&user_name='+fName+'&last_name='+lName+'&email_id='+email+'&state='+state+'&city='+city+'&party_id='+party+'&footeroption='+footeroption+'&designationtitle='+designationtitle+'&leadersname='+leadersname+'&facebook='+facebook+'&twitter='+tweeter+'&instagram='+instagram+'&koo='+koo,
    {}
    )
  }

  otpVerify(mobile, otp): Observable<any> {
    return this.http.post(this.env.API_URL + 'verify_otp?'+this.env.API_ACCESS_TOKEN+''+'&mobile_no='+mobile+'&mobile_otp='+otp,{})
    .pipe(
      tap(mobile => {
        this.storageService.store('mobile', mobile)
        .then(
          () => {
            //console.log('Mobile Stored');
            //this.authenticationState.next(true);
          },
          error => console.error('Error storing item', error)
        );
      }),
    );
  }

  logout() {
    return this.storageService.removeStorageItem('token').then(res => {
      this.storageService.removeStorageItem('mobile');
      this.storageService.removeStorageItem('registerStatus');
      this.authenticationState.next(false);
      this.router.navigate(['home']);
    });
  }

  isAuthenticated() {
    if (!this.authenticationState.value) {
      this.router.navigate(['home']);
    }
    return this.authenticationState.value;
  }

  user() {
    return this.storageService.get('token').then(
      data => {
        this.token = data;
       }
    );
  }

  getToken() {
    return this.storageService.get('token').then(
      data => {
        this.token = data;
        
        if(this.token != null) {
          this.isLoggedIn=true;
        } else {
          this.isLoggedIn=false;
        }
      },
      error => {
        this.token = null;
        this.isLoggedIn=false;
      }
    );
  }

  getState() {
    return this.http.get<any>(this.env.API_URL+'get_state_list?'+this.env.API_ACCESS_TOKEN)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  getCity(sid) {
    return this.http.get<any>(this.env.API_URL+'get_city_list?'+this.env.API_ACCESS_TOKEN+'&state='+sid)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  getParties() {
    return this.http.get<any>(this.env.API_URL+'get_party_list?'+this.env.API_ACCESS_TOKEN)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  getPartiesFooter(pid) {
    return this.http.get<any>(this.env.API_URL+'get_party_byid?'+this.env.API_ACCESS_TOKEN+'&id='+pid)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  getUserProfile(uid){
    return this.http.get<any>(this.env.API_URL+'get_user_profile?'+this.env.API_ACCESS_TOKEN+'&id='+uid)
      .pipe(
        map((data) => {
          return data;
        })
    );
  }
}

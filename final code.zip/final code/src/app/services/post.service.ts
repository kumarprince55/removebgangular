import { Injectable } from '@angular/core';
//import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { EnvService } from './env.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PostService {
  postData: any;

  constructor(
    private http: HttpClient,
    private env: EnvService,
  ) { }

  getPost(userId, partyId, selectedDate) {
    return this.http
      .get<any>(this.env.API_URL + 'create_user_wall_post?'+this.env.API_ACCESS_TOKEN+''+'&user_id='+userId+'&party_id='+partyId+'&date='+selectedDate)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  getDummyPost(){
   // https://electionadvisor.in/eadvisor/Api_controller/get_new_templatelist?token=4eb513bea08bacc63758d0dcee1a186a
    return this.http.get<any>(this.env.API_URL + 'get_new_templatelist?'+this.env.API_ACCESS_TOKEN)
    .pipe(
      map((data) => {
        return data;
      })
    );
  }

}

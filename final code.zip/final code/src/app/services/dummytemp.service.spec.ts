import { TestBed } from '@angular/core/testing';

import { DummytempService } from './dummytemp.service';

describe('DummytempService', () => {
  let service: DummytempService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DummytempService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

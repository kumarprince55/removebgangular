import { Injectable } from '@angular/core';
//import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { EnvService } from './env.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  constructor(
    private http: HttpClient,
    private env: EnvService,
  ) { }

  getPayment(uid, pid) {
    return this.http.post(this.env.API_URL + 'user_payment_status?'+this.env.API_ACCESS_TOKEN+''+'&id='+uid+'&paymentid='+pid,{})
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  getPlans(){
    return this.http
    .get<any>(this.env.API_URL + 'get_plan_list?token=4eb513bea08bacc63758d0dcee1a186a&')
    .pipe(
      map((data) => {
        return data;
      })
    );
  }

}

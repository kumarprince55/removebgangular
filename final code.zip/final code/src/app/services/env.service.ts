import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EnvService {
  API_ACCESS_TOKEN = 'token=4eb513bea08bacc63758d0dcee1a186a';
  API_ACCESS_TOKEN_ONLY = '4eb513bea08bacc63758d0dcee1a186a';
  API_URL = 'https://indiareportcard.com/ecapp/Api_controller/';
  Image_URL = 'https://indiareportcard.com/public/templete_bg_image/'
  Vdo_url = ''
  constructor() { }
}

import { Injectable } from '@angular/core';
import { EnvService } from './env.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class DummytempService {

  constructor(
    private http: HttpClient,
    private env: EnvService,
  ) { }

  getDpost() {
    return this.http
      .get<any>(this.env.API_URL + 'random_post')
      .pipe(
        map((data) => {
          return data;
        })
      );
  }

  getDpostByPid(pid) {
    return this.http.get<any>(this.env.API_URL + 'party_wise_post?'+'&party_id='+pid)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }
  
}

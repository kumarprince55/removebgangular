import { Injectable } from '@angular/core';
import { EnvService } from './env.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class LeadersService {

  constructor(
    private http: HttpClient,
    private env: EnvService,
  ) { }


  getLeadersList(){
    return this.http.get<any>(this.env.API_URL + 'getleaders?'+this.env.API_ACCESS_TOKEN+'&party_id=1')
     .pipe(
       map((data) => {
         return data;
      })
    );
  }

}

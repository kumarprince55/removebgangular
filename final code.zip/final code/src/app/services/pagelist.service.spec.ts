import { TestBed } from '@angular/core/testing';

import { PagelistService } from './pagelist.service';

describe('PagelistService', () => {
  let service: PagelistService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PagelistService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

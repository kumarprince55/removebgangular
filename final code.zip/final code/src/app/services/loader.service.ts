import { Injectable } from '@angular/core';
import { LoadingController } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class LoaderService {
  isLoading = false;
  constructor(public loadingController: LoadingController) {}


  async presentLoading() {
    const loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Please wait...',
      duration: 2000
    });
    await loading.present();
    const { role, data } = await loading.onDidDismiss();
  }
  // async presentLoading() {
  //   this.isLoading = true;
  //   return await this.loadingController.create().then(a => {
  //     a.present().then(() => {
  //       if (!this.isLoading) {
  //         a.dismiss();
  //       }
  //     });
  //   });
  // }
  // async dismiss() {
  //   if (this.isLoading) {
  //     this.isLoading = false;
  //     return await this.loadingController.dismiss();
  //   }
  //   return null;
  // }
}

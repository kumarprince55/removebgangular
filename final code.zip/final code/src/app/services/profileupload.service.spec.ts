import { TestBed } from '@angular/core/testing';

import { ProfileuploadService } from './profileupload.service';

describe('ProfileuploadService', () => {
  let service: ProfileuploadService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProfileuploadService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { Injectable } from '@angular/core';
import { EnvService } from './env.service';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class PagelistService {

  constructor(
    private http: HttpClient,
    private env: EnvService,
  ) { }

  getPages() {
    return this.http
      .get<any>(this.env.API_URL + 'get_pages_list?'+this.env.API_ACCESS_TOKEN)
      .pipe(
        map((data) => {
          return data;
        })
      );
  }
}

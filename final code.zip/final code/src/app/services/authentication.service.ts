import { Platform, LoadingController, AlertController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { tap, map } from 'rxjs/operators';
import { Storage } from '@capacitor/storage';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';
import { EnvService } from './env.service';
const TOKEN_KEY = 'auth-token';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  
  authenticationState = new BehaviorSubject(false);

  constructor(
    private http: HttpClient,
    private loadingController: LoadingController,
    private storage: Storage, 
    private env:EnvService,
    private plt: Platform,
    private router: Router,
    public alertController: AlertController
    ) { 
    this.plt.ready().then(() => {
      this.checkToken();
    });
  }

  checkToken() {
    this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        this.authenticationState.next(true);
      }
    })
  }

  mobileOtp(mobile) {
    return this.http
      .get<any>(this.env.API_URL + 'user_forgot_otp?'+this.env.API_ACCESS_TOKEN+''+'&mobile_no='+mobile)
      .pipe(
        tap(mobile => {
          this.storage.set('mobile', mobile)
          .then(
            () => {
              //console.log('Token Stored');
            },
            error => console.error('Error storing item', error)
          );
        }),
        map((data) => {
          //console.log(data);
          return data;
        })
      );
  }


  login(values) {
    
    const uploadData = new FormData(); // declar form object
    uploadData.append('email', values.email);
    uploadData.append('password', values.password);
    
    this.loadingController.create({keyboardClose: true, message: 'Loging In ...'})
      .then(loadingEl => {
        loadingEl.present(); // show loading
        this.http.post<any>('http://example.com/api', uploadData)
        .subscribe(
          res => {
            loadingEl.dismiss(); // hide loading
            // example return data 
            // res = { isSuccess: true, tokenKey: 'token-key', others: 'others..' }
            if (res.isSuccess) { 
              return this.storage.set(TOKEN_KEY, res.tokenKey).then(() => {
                this.authenticationState.next(true);
              });
            } else {
              this.loginFailedAlert();
              this.logout();
            }
          },
          err => {
            this.logout();
            console.log(err);
          }
        );
      });
  }

  logout() {
    return this.storage.remove(TOKEN_KEY).then(() => {
      this.authenticationState.next(false);
      this.router.navigate(['login']);
    });
  }
 
  isAuthenticated() {
    if (!this.authenticationState.value) {
      this.router.navigate(['login']);
    }
    return this.authenticationState.value;
  }

  async registerFailedAlert(str) {
    const alert = await this.alertController.create({
      header: 'Registration Invalid!',
      message: str,
      buttons: ['OK']
    });

    await alert.present();
  } 

  async loginFailedAlert() {
    const alert = await this.alertController.create({
      header: 'Login Invalid!',
      message: 'Please login with valid username and password.',
      buttons: ['OK']
    });

    await alert.present();
  }

}
import { Component, OnInit } from '@angular/core';
import { ModalController, NavController } from '@ionic/angular';
import { NgForm } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { AlertService } from 'src/app/services/alert.service';
import { StorageService } from '../services/storage.service';
import { RegisterPage } from '../register/register.page';
@Component({
  selector: 'app-otp-verify',
  templateUrl: './otp-verify.page.html',
  styleUrls: ['./otp-verify.page.scss'],
})
export class OtpVerifyPage implements OnInit {
  smob: number;
  motp: number;
  checkMotp: number;
  registerCheck: boolean;

  constructor(
    public modalCtrl: ModalController,
    private authService: AuthService,
    private navCtrl: NavController,
    private storageService: StorageService,
    private alertService: AlertService
  ) {}

  ngOnInit() {
    this.getNumber();
  }

  getNumber() {
    return this.storageService.get('registerStatus').then(
      (data) => {
        this.smob = data.mobile_no;
        this.checkMotp = data.mobile_otp;
        this.registerCheck = data.register;
      },
      (error) => {
        // this.mobile = null;
        // this.isLoggedIn=false;
      }
    );
  }

  async dismiss() {
    return await this.modalCtrl.dismiss();
  }

  async keyPressAlphaNumeric(event) {
    var inp = String.fromCharCode(event.keyCode);
    if (/[0-9]/.test(inp)) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  async otpAuth(form: NgForm) {
    console.log(this.checkMotp.toString() + '||' + form.value.otp.toString() + '||'+ this.registerCheck);
    console.log(this.checkMotp.toString() === form.value.otp.toString());

    if (this.checkMotp.toString() === form.value.otp.toString()) {
      if (this.registerCheck === true) {
        this.login(this.smob, this.checkMotp);
        this.alertService.presentToast('Login');
      }else{
        this.registerModel();
        this.dismiss();
      }
    } else {
      this.alertService.presentToast('Please Enter Valid OTP');
    }
    this.authService
      .otpVerify(this.smob, form.value.otp)
      .subscribe((data) => {});
  }
 
  async login(mobile, motp) {
    this.authService.login(mobile, motp).subscribe(
      (data) => {
          this.alertService.presentToast('Logged In');
          this.navCtrl.navigateRoot('dashboard');
          this.dismiss();
      },
      (error) => {
        console.log(error);
      }
    );
  }

  async registerModel() {
    const modal = await this.modalCtrl.create({
      component: RegisterPage,
      animated: true,
      mode: 'ios',
      backdropDismiss: false,
      cssClass: 'register-modal',
    });

    return await modal.present();
  }
}

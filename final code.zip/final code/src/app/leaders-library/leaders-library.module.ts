import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LeadersLibraryPageRoutingModule } from './leaders-library-routing.module';

import { LeadersLibraryPage } from './leaders-library.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LeadersLibraryPageRoutingModule
  ],
  declarations: [LeadersLibraryPage]
})
export class LeadersLibraryPageModule {}

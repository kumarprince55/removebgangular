import { Component, OnInit } from '@angular/core';
import { ModalController, NavController } from '@ionic/angular';
import { LeadersService } from 'src/app/services/leaders.service';

@Component({
  selector: 'app-leaders-library',
  templateUrl: './leaders-library.page.html',
  styleUrls: ['./leaders-library.page.scss'],
})
export class LeadersLibraryPage implements OnInit {

  leadersList: any;
  constructor( 
    public modalCtrl: ModalController,
    private leaderService: LeadersService,
    ) { }

  ngOnInit() {
    this.leadersData();
  }

  leadersData() {
    this.leaderService.getLeadersList().subscribe((res) => {
      console.log(res);
      this.leadersList = res.leader_post;
    });
  }

}

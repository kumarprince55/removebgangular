export class User {
    success: true;
    id: number;
    first_name: string;
    last_name: string;
    full_name: string;
    email: string;
    mobile_no: number;
    password: string;
    role_id: number;
    state_id: number;
    district_id: number;
    facebook_tokon: string;
    tweeter_tokon: string;
    user_image: string;
    status: number;
    party_id: number;
    login_time: string;
    logged_in: true
}
import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { NgForm } from '@angular/forms';
import { LoaderService } from 'src/app/services/loader.service';
import { AlertService } from 'src/app/services/alert.service';
import { Location } from '@angular/common';
import { PopoverController } from '@ionic/angular';
import { ProfilepopoverComponent } from '../profilepopover/profilepopover.component';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {
  public authUser: any;
  id: any;
  user_name: any;
  last_name: any;
  email: any;
  state: any;
  city: any;
  stateList: any;
  cityList: any;
  sid: any;
  party:any;
  partyList: any;
  userData: any;
  footerList: any;
  footeroption: any;
  designationtitle: any;
  leadersname: any;
  facebook: any;
  tweeter: any;
  instagram: any;
  koo: any;
  radioVal: any;
  userPic:any;
  constructor(
    private authService: AuthService,
    private location: Location,
    private popoverCtrl: PopoverController,
    private loaderService: LoaderService,
    private alertService: AlertService
  ) {}

  ngOnInit() {
    this.getPartyList();
    this.getStateList();
    this.userInfo();
  }

  async userInfo() {
    this.authService.user().then(() => {
      if (this.authService.isAuthenticated) {
        this.authUser = this.authService.token;
        this.userProfileDetail(this.authUser.id);
      }
    });
  }

  userProfileDetail(uid) {
    this.authService.getUserProfile(uid).subscribe((res) => {
      console.log(res.user_detail);
      this.userData = res.user_detail;
      this.id = this.userData.id;
      this.user_name = this.userData.first_name;
      this.last_name = this.userData.last_name;
      this.email = this.userData.email;
      this.state = this.userData.state_id;
      this.city = this.userData.district_id;
      this.party = this.userData.party_id;
      this.footeroption = this.userData.footeroption;
      this.designationtitle = this.userData.designationtitle;
      this.leadersname = this.userData.leadersname;
      this.facebook = this.userData.facebook;
      this.tweeter = this.userData.tweeter;
      this.instagram = this.userData.instagram;
      this.koo = this.userData.koo;
      this.userPic = this.userData.user_image;
      //console.log(this.footeroption);
      this.getCity(this.state);
      //this.getFooters(this.party);
    });
  }

  async showPopover(event) {
    const popover = await this.popoverCtrl.create({
      component: ProfilepopoverComponent,
      showBackdrop: true,
      mode: 'ios',
      cssClass: 'user-profile',
      event,
    });
    await popover.present();
  }

  async updateProfile(form: NgForm) {
    form.value.id = this.id;
    this.loaderService.presentLoading();

    console.log(this.radioVal);
    this.authService
      .updateProfile(
        form.value.id,
        form.value.user_name,
        form.value.last_name,
        form.value.email,
        form.value.state,
        form.value.city,
        form.value.party,
        form.value.footeroption = this.radioVal,
        form.value.designationtitle,
        form.value.leadersname,
        form.value.facebook,
        form.value.tweeter,
        form.value.instagram,
        form.value.koo,
      )
      .subscribe(
        (data) => {
          this.alertService.presentToast('Updated Successfully');
          this.userProfileDetail(form.value.id);
        },
        (error) => {
          console.log(error);
        }
      );
  }

  onBackButtonClick() {
    this.location.back();
  }

  getStateList() {
    this.authService.getState().subscribe((res) => {
      this.stateList = res.state_list;
    });
  }
  getCity(sid) {
    this.authService.getCity(sid).subscribe((res) => {
      this.cityList = res.city_list;
    });
  }
  async onSelectState(e) {
    const sid = e.target.value;
    this.getCity(sid);
  }

  getPartyList(){
    this.authService.getParties().subscribe((res) => {
      this.partyList = res.party_list;
    });
  }

  onchangeParty(e){
    const pid = e.target.value;
    //this.getFooters(pid);
  }

  onRadioChange(value) {
    // this.form.get('typeofsession').setValue(value, {
    //   onlyself: true,
    // });
    // this.form.get('typeofsession').setValue(value)
    this.radioVal = value;
    console.log(value);
  }

  // getFooters(pid){
  //   this.authService.getPartiesFooter(pid).subscribe((res) => {
  //     this.footerList = res.party_list.options;
  //     console.log(this.footerList)
  //   });
  // }

  
}

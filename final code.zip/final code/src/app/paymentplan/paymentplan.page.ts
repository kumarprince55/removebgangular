import { Component, OnInit } from '@angular/core';
import { PaymentService } from 'src/app/services/payment.service';
import { AuthService } from 'src/app/services/auth.service';
import { AlertService } from 'src/app/services/alert.service';
import { PopoverController } from "@ionic/angular";
import { ProfilepopoverComponent } from "../profilepopover/profilepopover.component";
import  'capacitor-razorpay';
import { Location } from "@angular/common";
import { Plugins } from '@capacitor/core';
const { Checkout } = Plugins;
@Component({
  selector: 'app-paymentplan',
  templateUrl: './paymentplan.page.html',
  styleUrls: ['./paymentplan.page.scss'],
})
export class PaymentplanPage implements OnInit {
  
  public authUser: any;
  userName: any;
  userID: any;
  emailId: any;
  mobile: any;
  plans: any;
  userData: any;


  constructor( private paymentService: PaymentService, private popoverCtrl: PopoverController, private location: Location, private authService: AuthService, private alertService: AlertService) { }

  ngOnInit() {
    this.userInfo();
    this.getPlansList();
  }



  async showPopover(event) {
    const popover = await this.popoverCtrl.create({
      component: ProfilepopoverComponent,
      showBackdrop: true,
      mode: 'ios',
      cssClass: "user-profile",
      event
    });
    await popover.present();
  }

  getPlansList() {
    this.paymentService.getPlans().subscribe((data) => {
      this.plans = data.plan_list;
    });
  }


  
  async loadCheckout(fld_price) {
    const options = { 
      key: 'rzp_live_rDbAntssbzc4G8',
      amount: fld_price * 100,
      description: 'Annual Subscription', 
      image: '../../assets/icon/logo.png', 
      currency: 'INR', 
      name: 'Election Adviser', 
      prefill: { 
        email: this.emailId, 
        contact: this.mobile, 
        name: this.userName
      },
      theme: {
        color: '#F37254'
      }
    }
    try {
    let data = (await Checkout.open(options));

    const paymentID = data.response.razorpay_payment_id;
      this.paymentService.getPayment(this.userID, paymentID).subscribe((data) => {
        this.alertService.presentToast('Payment Success');
        this.location.back();
      });
    
    } catch (error) {
      this.alertService.presentToast(error.message);
    }
  }

  userlogout() {
    this.authService.logout();
  }

  onBackButtonClick(){
    this.location.back();
  }

  userInfo() {
    this.authService.user().then(() => {
      if (this.authService.isAuthenticated) {
        this.authUser = this.authService.token;
        this.userID = this.authUser.id;
        this.userProfileDetail(this.authUser.id);
      }
    });
  }

  userProfileDetail(uid){
    this.authService.getUserProfile(uid).subscribe((res) => {
      this.userData = res.user_detail;
      this.userName = this.userData.first_name +' '+ this.userData.last_name;
      this.emailId = this.userData.email;
      this.mobile = this.userData.mobile_no;

    });
  }
}

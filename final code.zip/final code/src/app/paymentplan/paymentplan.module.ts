import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PaymentplanPageRoutingModule } from './paymentplan-routing.module';

import { PaymentplanPage } from './paymentplan.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PaymentplanPageRoutingModule
  ],
  declarations: [PaymentplanPage]
})
export class PaymentplanPageModule {}

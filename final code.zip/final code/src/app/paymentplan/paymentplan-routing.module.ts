import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PaymentplanPage } from './paymentplan.page';

const routes: Routes = [
  {
    path: '',
    component: PaymentplanPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PaymentplanPageRoutingModule {}

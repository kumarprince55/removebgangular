import { Component, OnInit } from '@angular/core';
import { PagelistService } from 'src/app/services/pagelist.service';
import { AuthService } from 'src/app/services/auth.service';
import { PopoverController } from '@ionic/angular';
import { ProfilepopoverComponent } from '../profilepopover/profilepopover.component';
@Component({
  selector: 'app-termscondition',
  templateUrl: './termscondition.page.html',
  styleUrls: ['./termscondition.page.scss'],
})
export class TermsconditionPage implements OnInit {

  pageList:any;
  public authUser: any;
  userData: any;
  paymentStatus: number;
  about:any;
  services:any;
  privacy:any;
  termscondition:any;
  userPic: any;
  constructor(
    private popoverCtrl: PopoverController,
    private pagelistService: PagelistService,
    private authService: AuthService,
  ) { }

  ngOnInit() {
    this.getPage();
    this.userInfo();
  }

  async showPopover(event) {
    const popover = await this.popoverCtrl.create({
      component: ProfilepopoverComponent,
      showBackdrop: true,
      mode: 'ios',
      cssClass: 'user-profile',
      event,
    });
    await popover.present();
  }

  async userInfo() {
    this.authService.user().then(() => {
      if (this.authService.isAuthenticated) {
        this.authUser = this.authService.token;
        this.userProfileDetail(this.authUser.id);
      }
    });
  }

  async userProfileDetail(uid) {
    this.authService.getUserProfile(uid).subscribe((res) => {
      this.userData = res.user_detail;
      this.paymentStatus = res.user_detail.payment_status;
      this.userPic = this.userData.user_image;
      
    });
  }

  getPage(){
    this.pagelistService.getPages().subscribe((res)  =>  {
      console.log(res);
      this.pageList = res.page_list;

      this.about = this.pageList[0];
      this.privacy = this.pageList[1];
      this.termscondition = this.pageList[2];
      this.services = this.pageList[3]


    });
  }

}

import { Component } from '@angular/core';
import { RegisterPage } from '../register/register.page';
import { ModalController, NavController } from '@ionic/angular';
import { NgForm } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { AlertService } from 'src/app/services/alert.service';
import { OtpVerifyPage } from '../otp-verify/otp-verify.page';
import { LoaderService } from 'src/app/services/loader.service';
import { DummytempService } from 'src/app/services/dummytemp.service';
import { StorageService } from '../services/storage.service';
@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  showAuth: boolean;
  dpost: any;
  
  constructor(
    public modalCtrl: ModalController,
    private authService: AuthService,
    private navCtrl: NavController,
    private alertService: AlertService,
    private storageService: StorageService,
    private dummytempService: DummytempService,
    private loaderService: LoaderService) {}

    ngOnInit() {
      this.storageService.get('token').then(
        (data) => {
          if (data.value !== null) {
            this.showAuth = data.mobile_no;
           }else {
            console.log(data.value)
           }
        })
        this.getDpost();
    }
  
    dismissLogin() {
      this.modalCtrl.dismiss();
    }

  async login(form: NgForm) {
    const mobileVal = form.value.mobile.length;
    if(mobileVal >= 10){
      this.loaderService.presentLoading();
      this.authService.loginOtp(form.value.mobile).subscribe(
        data => {
          this.otpverifyModel()
          console.log(data);
          this.alertService.presentToast("OTP send to your mobile number");
        },
        error => {
          console.log(error);
        }
      );
    }else{
      this.alertService.presentToast("Enter a valid mobile number");
    }
  }

  async keyPressAlphaNumeric(event) {
    var inp = String.fromCharCode(event.keyCode);
    if (/[0-9]/.test(inp)) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  async otpverifyModel() {
    const modal = await this.modalCtrl.create({
      component: OtpVerifyPage,
      animated: true,
      mode: 'ios',
      backdropDismiss: false,
      cssClass: 'otp-modal',
    })

    return await modal.present();
  }

  async dismiss() {
    return await this.modalCtrl.dismiss();
  }
  
  async register() {
    const modal = await this.modalCtrl.create({
      component: RegisterPage,
      animated: true,
      mode: 'ios',
      backdropDismiss: false,
      cssClass: 'register-modal',
    })

    return await modal.present();
  }

  async reauth(){
      return this.storageService.get('token').then(
        (data) => {
           if (data.value !== null) {
            this.navCtrl.navigateRoot('dashboard');
           }else {
            console.log(data.value)
           }
        },
        (error) => {
          // this.mobile = null;
          // this.isLoggedIn=false;
        }
      );
  }

  getDpost(){
      return this.dummytempService.getDpost().subscribe(
        data => {
          console.log(data.user_post);
          this.dpost = data.user_post;
        },
        error => {
          console.log(error);
        }
      );
  }
}
